import tkinter as tk

class YesNoPrompt:
    def __init__(self, root, question):
        self.root = root
        self.question = question
        self.user_answer = None
        self.create_window()

    def create_window(self):
        self.window = tk.Toplevel(self.root)
        self.window.title("Yes/No Question")

        # Display the question
        question_label = tk.Label(self.window, text=self.question)
        question_label.pack(pady=20)

        # Yes button
        yes_button = tk.Button(self.window, text="Yes", command=self.on_yes)
        yes_button.pack(side="left", padx=20, pady=10)

        # No button
        no_button = tk.Button(self.window, text="No", command=self.on_no)
        no_button.pack(side="right", padx=20, pady=10)

    def on_yes(self):
        self.user_answer = True
        self.close_window()
        self.root.quit()

    def on_no(self):
        self.user_answer = False
        self.close_window()
        self.root.quit()

    def close_window(self):
        self.window.destroy()
        self.root.quit()

# Example usage
def ask_question():
    root = tk.Tk()
    root.withdraw()  # Hide the main window
    prompt = YesNoPrompt(root, "By proceeding you agree to have your mouse, keyboard and score data collected.")
    root.mainloop()

ask_question()