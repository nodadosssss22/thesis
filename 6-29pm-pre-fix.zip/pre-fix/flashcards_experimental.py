import json
import os
import time
import tkinter as tk
from tkinter import simpledialog, messagebox


def flash_process():
    class FlashcardProgress:
        def __init__(self, root, flashcards, user_name, save_file="progress.json"):
            self.save_file = save_file
            self.flashcards = flashcards
            self.user_name = user_name
            self.current_index = self.load_progress()
            self.score = 0
            self.user_answers = []  # To store user answers
            self.root = root
            self.selected_answer = tk.StringVar()

            # GUI Components
            self.frame = tk.Frame(root)
            self.frame.pack(pady=20)
            self.question_label = tk.Label(self.frame, text="", wraplength=400)
            self.question_label.pack()
            self.multiple_choice_area = None
            self.coding_input_area = None
            self.next_button = tk.Button(self.frame, text="Next", command=self.show_next_flashcard)
            self.next_button.pack(pady=10)

            self.show_flashcard()

        def save_progress(self):
            data = []
            if os.path.exists(self.save_file):
                with open(self.save_file, "r") as file:
                    try:
                        data = json.load(file)
                        if not isinstance(data, list):  # Ensure data is a list
                            print("Progress file does not contain a list. Resetting progress.")
                            data = []
                    except json.JSONDecodeError:
                        print("Progress file is corrupted. Starting fresh.")
                        data = []

            # Append new progress entry
            new_entry = {
                "time": time.time(),
                "user_name": self.user_name,
                "current_index": self.current_index,
                "score": self.score,
                "answers": self.user_answers,
            }
            data.append(new_entry)

            # Save updated data back to the file
            with open(self.save_file, "w") as file:
                json.dump(data, file, indent=4)

        def load_progress(self):
            if os.path.exists(self.save_file):
                with open(self.save_file, "r") as file:
                    try:
                        data = json.load(file)
                        if isinstance(data, list) and data:  # Ensure it's a non-empty list
                            latest_entry = data[-1]  # Get the most recent entry
                            self.score = latest_entry.get("score", 0)
                            return latest_entry.get("current_index", 0)
                    except json.JSONDecodeError:
                        print("Progress file is corrupted. Starting fresh.")
                        return 0
            return 0

        def show_flashcard(self):
            if self.current_index >= len(self.flashcards):
                self.question_label.config(
                    text=f"Quiz complete! Your score is {self.score}/{self.get_total_questions()}."
                )
                self.next_button.config(state=tk.DISABLED)
                messagebox.showinfo("Flashcards", f"You finished the quiz! Final score: {self.score}")
                os.remove(self.save_file)
                return

            question_data = self.flashcards[self.current_index]
            question = question_data["question"]
            q_type = question_data["type"]
            self.question_label.config(text=question)

            if self.multiple_choice_area:
                self.multiple_choice_area.destroy()

            if self.coding_input_area:
                self.coding_input_area.destroy()

            if q_type == "multiple choice":
                self.multiple_choice_area = tk.Frame(self.frame)
                self.multiple_choice_area.pack(pady=10)
                for choice in question_data["choices"]:
                    tk.Radiobutton(
                        self.multiple_choice_area,
                        text=choice,
                        variable=self.selected_answer,
                        value=choice,
                    ).pack(anchor="w")

            elif q_type == "coding":
                self.question_label.config(text=f"Think about the following coding task:\n\n{question}")
                self.coding_input_area = tk.Text(self.frame, height=10, width=50)
                self.coding_input_area.pack(pady=10)

        def show_next_flashcard(self):
            if self.current_index < len(self.flashcards):
                question_data = self.flashcards[self.current_index]
                question_number = self.current_index + 1

                # Validate user input
                if question_data["type"] == "coding":
                    user_input = self.coding_input_area.get("1.0", tk.END).strip()
                    if not user_input:
                        messagebox.showerror("Error", "Please provide an answer before proceeding.")
                        return
                    # Save user input
                    self.user_answers.append({
                        "user": self.user_name,
                        "question_number": question_number,
                        "answer": user_input
                    })

                elif question_data["type"] == "multiple choice":
                    correct_answer = question_data.get("correct_answer")
                    user_input = self.selected_answer.get()
                    if user_input == correct_answer:
                        self.score += 1
                    # Save user input
                    self.user_answers.append({
                        "user": self.user_name,
                        "question_number": question_number,
                        "answer": user_input
                    })

                self.current_index += 1
                self.save_progress()
                self.show_flashcard()

        def get_total_questions(self):
            return len([q for q in self.flashcards if q["type"] == "multiple choice"])

    def get_user_name():
        def start_flashcards():
            user_name = name_entry.get().strip()
            if not user_name:
                messagebox.showerror("Error", "Please enter your name to proceed.")
                return
            name_window.destroy()
            root = tk.Tk()
            root.title("Flashcard Viewer with Score Tracking")
            root.geometry("500x500")
            FlashcardProgress(root, flashcards, user_name)
            root.mainloop()

        name_window = tk.Tk()
        name_window.title("User Information")
        name_window.geometry("300x150")
        tk.Label(name_window, text="Enter your name:").pack(pady=10)
        name_entry = tk.Entry(name_window)
        name_entry.pack(pady=5)
        tk.Button(name_window, text="Start", command=start_flashcards).pack(pady=10)
        name_window.mainloop()

    flashcards = [
        {"question": "What is Python?", "type": "multiple choice", 
        "choices": ["A language", "An animal", "A framework"], "correct_answer": "A language"},
        {"question": "Write a function to reverse a string.", "type": "coding"},
        {"question": "What is the difference between a list and a tuple?", "type": "multiple choice", 
        "choices": ["Mutable vs Immutable", "Ordered vs Unordered", "None"], "correct_answer": "Mutable vs Immutable"},
        {"question": "What is a lambda function in Python?", "type": "multiple choice", 
        "choices": ["A function with no name", "A module in Python", "A class"], "correct_answer": "A function with no name"},
    ]

    get_user_name()
